# shein_api.py
import json, requests, os, random, glob

def get_random_cookie(cookies_dir):
    files = glob.glob(os.path.join(cookies_dir, "*.json"))
    if not files: 
        print("📁 [VERBOSE] No cookie files found!")
        return None, None
    
    chosen_file = random.choice(files)
    fname = os.path.basename(chosen_file)
    
    try:
        with open(chosen_file, "r", encoding="utf-8") as f:
            data = json.loads(f.read())
            if isinstance(data, list):
                cookie_str = "; ".join(f"{c['name']}={c['value']}" for c in data if 'name' in c)
            else:
                cookie_str = "; ".join(f"{k}={v}" for k, v in data.items())
            return cookie_str.strip(), fname
    except:
        return None, None

def get_headers(cookie_string):
    return {
        "accept": "application/json",
        "content-type": "application/json",
        "origin": "https://www.sheinindia.in",
        "referer": "https://www.sheinindia.in/cart",
        "user-agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36",
        "x-tenant-id": "SHEIN",
        "cookie": cookie_string
    }

def validate_session(session, headers, filename):
    url = "https://www.sheinindia.in/api/cart/apply-voucher"
    payload = {"voucherId": "SESSION_PROBE_999", "device": {"client_type": "web"}}
    
    print(f"📡 [VERBOSE] Probing {filename}...")
    try:
        res = session.post(url, json=payload, headers=headers, timeout=15)
        print(f"📊 [VERBOSE] HTTP Status: {res.status_code}")
        
        # FIX: SHEIN returns 400 for invalid vouchers even if session is ALIVE
        if res.status_code in [200, 400]:
            res_data = res.json()
            print(f"📥 [VERBOSE] SHEIN Response: {json.dumps(res_data)}")
            
            err_msg = str(res_data.get("errorMessage", "")).lower()
            
            # Agar 'login' ya 'sign in' nahi hai, matlab session active hai
            if "login" not in err_msg and "sign in" not in err_msg and "unauthorized" not in err_msg:
                print(f"✅ [VERBOSE] Session is ALIVE for {filename}")
                return True
            else:
                print(f"⚠️ [VERBOSE] Session EXPIRED (Login Required)")
        else:
            print(f"🚫 [VERBOSE] Blocked by Cloudflare/Server. Status: {res.status_code}")
            
        return False
    except Exception as e:
        print(f"💥 [VERBOSE] Request Failed: {e}")
        return False

def check_voucher_session(session, voucher_code, headers):
    url = "https://www.sheinindia.in/api/cart/apply-voucher"
    payload = {"voucherId": voucher_code, "device": {"client_type": "web"}}
    try:
        res = session.post(url, json=payload, headers=headers, timeout=25)
        return res.json()
    except:
        return None

# YAHAN FIX HAI: Missing reset_voucher_session function add kiya
def reset_voucher_session(session, voucher_code, headers):
    url = "https://www.sheinindia.in/api/cart/reset-voucher"
    payload = {"voucherId": voucher_code, "device": {"client_type": "web"}}
    try:
        session.post(url, json=payload, headers=headers, timeout=15)
    except:
        pass

def is_voucher_applicable(data):
    if not data: return False
    # No error message means voucher is VALID
    if "errorMessage" not in data or not data.get("errorMessage"): 
        return True
    
    # Detailed error check
    err_obj = data.get("errorMessage", {})
    if isinstance(err_obj, dict):
        errors = err_obj.get("errors", [])
        for e in errors:
            msg = e.get("message", "").lower()
            # If it says 'not applicable', it's DEAD. 
            # If it says anything else (like 'System busy'), we keep it for safety.
            if "not applicable" in msg or "invalid" in msg:
                return False
    return False
    