# bot_handlers.py
import threading, os, re, time
import database as db
import referral_db as rdb
import checker
import live_activity 
import keyboards as kb  
from config import ADMIN_ID, REQUIRED_CHATS

def register_all_handlers(bot):

    def is_user_joined(user_id):
        """Checks if the user is a member of all required chats."""
        for chat in REQUIRED_CHATS:
            try:
                member = bot.get_chat_member(chat, user_id)
                if member.status in ['left', 'kicked']:
                    return False
            except Exception:
                return False
        return True

    # --- COMMAND HANDLERS ---
    
    @bot.message_handler(commands=['inspect'])
    def handle_inspect(message):
        # Admin check
        if str(message.from_user.id) != str(ADMIN_ID):
            return
            
        try:
            args = message.text.split()
            if len(args) < 2:
                bot.reply_to(message, "⚠️ Usage: `/inspect [UserID]`")
                return
                
            target_uid = args[1]
            data = db.inspect_user_vouchers(target_uid)
            
            report = f"🕵️ **USER INSPECTION:** `{target_uid}`\n"
            report += "──────────────────────\n"
            
            if not data:
                report += "❌ No data found for this user."
            else:
                total = 0
                for status, count in data:
                    report += f"● `{status}` ➜ `{count}`\n"
                    total += count
                report += f"\n📊 **Total Lifetime Entries:** `{total}`"
                
            bot.reply_to(message, report, parse_mode='Markdown')
            
        except Exception as e:
            bot.reply_to(message, f"❌ **Error Detail:** `{str(e)}`", parse_mode='Markdown')

    @bot.message_handler(commands=['setlimit'])
    def set_user_limit_manually(message):
        user_id = message.chat.id
        if user_id != ADMIN_ID:
            return 

        try:
            args = message.text.split()
            if len(args) == 3:
                target_id = int(args[1])
                amount = int(args[2])
                rdb.set_manual_limit(target_id, amount)
                bot.send_message(user_id, f"✅ **Limit Updated!**\n👤 User: `{target_id}`\n🚀 New Limit: `{amount}`", parse_mode='Markdown')
                try: bot.send_message(target_id, f"🎁 **SURPRISE!** Admin has updated your daily limit to **{amount}** vouchers. Enjoy!", parse_mode='Markdown')
                except: pass
            else:
                bot.send_message(user_id, "❌ **Usage:** `/setlimit [UserID] [Amount]`", parse_mode='Markdown')
        except Exception as e:
            bot.send_message(user_id, f"❌ **Error:** `{str(e)}`", parse_mode='Markdown')

    @bot.message_handler(commands=['start', 'stats', 'refer'])
    def handle_menu_commands(message):
        if message.chat.type != 'private':
            return 
            
        user_id = message.chat.id
        
        if not is_user_joined(user_id):
            join_msg = (
                "⚠️ **ACCESS DENIED**\n"
                "──────────────────────\n"
                "To use this bot, you must join our official groups and backup channel below.\n\n"
                "Join all links and click the verification button to continue!"
            )
            bot.send_message(user_id, join_msg, reply_markup=kb.get_join_keyboard(), parse_mode='Markdown')
            return

        if message.text.startswith('/start'):
            command_args = message.text.split()
            if len(command_args) > 1 and command_args[1].isdigit():
                rdb.log_referral_intent(user_id, int(command_args[1]))
                
            username = message.from_user.username or "N/A"
            db.add_user(user_id, "USER") 
            
            stats = db.get_stats(user_id) 
            limits = rdb.get_user_limits(user_id) 
            
            # --- STRICT ADAPT: UI for Unlimited vs Free ---
            is_vip = limits.get('is_unlimited', False)
            if is_vip:
                bar = "█" * 10
                limit_display = "Unlimited 🚀"
                remaining_display = "Unlimited"
                status_tier = "VIP Unlimited 👑"
            else:
                limit_val = limits['limit'] if limits['limit'] > 0 else 1
                percent = int((limits['used'] / limit_val) * 10)
                percent = min(max(percent, 0), 10) 
                bar = "█" * percent + "░" * (10 - percent)
                limit_display = f"{limits['used']} / {limits['limit']}"
                remaining_display = str(limits['remaining'])
                status_tier = "Free Tier 🆓"

            dashboard = (
                "👤 **USER DASHBOARD v4.2**\n"
                "━━━━━━━━━━━━━━━━━━\n\n"
                "🆔 **ACCOUNT INFO**\n"
                f"» Username : `@{username}`\n"
                f"» User ID  : `{user_id}`\n"
                f"» Tier     : `{status_tier}`\n"
                "» Status   : `Verified Member` ✅\n\n"
                "🧾 **VOUCHER STATS**\n"
                f"» Lifetime Valid : `{stats.get('VALID', 0)}`\n"
                f"» Lifetime Dead  : `{stats.get('INVALID', 0)}`\n\n"
                "⚡️ **DAILY QUOTA**\n"
                f"» Progress : `[{bar}]`\n"
                f"» Used Today : `{limit_display}`\n"
                f"» Remaining  : `{remaining_display}`\n\n"
                "👥 **COMMUNITY GROWTH**\n"
                f"» Total Referrals : `{limits['refers']} Members`\n"
                "━━━━━━━━━━━━━━━━━━\n"
                "🛠 **System Engine:** `Level Max` 🚀"
            )
            markup = kb.get_admin_keyboard() if user_id == ADMIN_ID else kb.get_user_keyboard()
            bot.send_message(user_id, dashboard, reply_markup=markup, parse_mode='Markdown')

        elif message.text.startswith('/stats'):
            message.text = "📊 My Stats"
            handle_text_buttons(message)

        elif message.text.startswith('/refer'):
            message.text = "👥 Refer & Earn"
            handle_text_buttons(message)

    # --- TEXT BUTTON HANDLERS ---
    @bot.message_handler(func=lambda msg: True)
    def handle_text_buttons(message):
        if message.chat.type != 'private':
            return 
            
        user_id = message.chat.id
        text = message.text

        if not is_user_joined(user_id) and user_id != ADMIN_ID:
            message.text = '/start'
            handle_menu_commands(message)
            return

        if text == "➕ Add Vouchers":
            m = bot.send_message(user_id, "📝 **Paste your vouchers here**\n(Click 'Back to Menu' if you want to cancel):", parse_mode='Markdown')
            bot.register_next_step_handler(m, process_add_vouchers)

        elif text == "📊 My Stats":
            stats = db.get_stats(user_id) 
            stats_msg = (
                "📊 **LIFETIME STATISTICS**\n"
                "━━━━━━━━━━━━━━━━━━\n"
                "⏳ **In Queue:** `{}`\n\n"
                "✅ **Total Valid:** `{}`\n"
                "❌ **Total Invalid:** `{}`\n"
                "🧾 **Total Checked:** `{}`\n"
                "━━━━━━━━━━━━━━━━━━\n"
                "⚠️ *Note: Stats include all re-checks and duplicate pastes.*"
            ).format(stats.get('PENDING', 0), stats.get('VALID', 0), stats.get('INVALID', 0), stats.get('TOTAL', 0))
            bot.send_message(user_id, stats_msg, parse_mode='Markdown')

        elif text == "👥 Refer & Earn":
            bot_info = bot.get_me()
            ref_link = f"https://t.me/{bot_info.username}?start={user_id}"
            stats = rdb.get_user_limits(user_id)
            
            # --- STRICT ADAPT: UI for Unlimited Referrals ---
            is_vip = stats.get('is_unlimited', False)
            if is_vip:
                status_text = "✅ **You have unlocked UNLIMITED vouchers!**"
            else:
                needed = max(0, 2 - stats['refers'])
                status_text = f"⚠️ **Invite {needed} more friend(s) to unlock UNLIMITED checking!**"
            
            ref_msg = (
                "👥 **REFER & EARN PROGRAM**\n"
                "━━━━━━━━━━━━━━━━━━\n"
                f"🚀 **UNLOCK UNLIMITED!** Invite just 2 friends to get lifetime unlimited voucher checks!\n\n"
                f"🔗 **Your Invite Link:**\n`{ref_link}`\n\n"
                "📊 **Your Referral Stats:**\n"
                f"» Total Invites: `{stats['refers']}`\n"
                f"{status_text}\n"
                "━━━━━━━━━━━━━━━━━━\n"
                "⚠️ *Note: Invites only count when your friend joins all mandatory channels.*"
            )
            bot.send_message(user_id, ref_msg, parse_mode='Markdown', disable_web_page_preview=True)

        elif text == "👥 Referral Manager" and user_id == ADMIN_ID:
            config = rdb.get_config()
            admin_ref_msg = (
                "⚙️ **GLOBAL REFERRAL MANAGER**\n"
                "━━━━━━━━━━━━━━━━━━\n"
                "🔧 **Current Configuration:**\n"
                f"» Base Daily Limit: `{config['base']}` vouchers\n"
                f"» Bonus Per Invite: `+{config['bonus']}` vouchers\n\n"
                "Select an action below to manage the referral system."
            )
            bot.send_message(user_id, admin_ref_msg, reply_markup=kb.get_ref_manager_inline(), parse_mode='Markdown')

        elif text == "📡 Live Activity" and user_id == ADMIN_ID:
            dashboard = live_activity.get_live_dashboard()
            bot.send_message(user_id, dashboard, reply_markup=kb.get_live_dashboard_inline(), parse_mode='Markdown')

        elif text == "⚙️ Admin Panel" and user_id == ADMIN_ID:
            bot.send_message(user_id, "⚙️ **ADMIN CONTROL CENTER**", reply_markup=kb.get_admin_panel_keyboard(), parse_mode='Markdown')

        elif text == "🛠️ Cookie Manager" and user_id == ADMIN_ID:
            threading.Thread(target=checker.run_cookie_manager, args=(bot, user_id)).start()

        elif text == "🔙 Back to Menu":
            markup = kb.get_admin_keyboard() if user_id == ADMIN_ID else kb.get_user_keyboard()
            bot.send_message(user_id, "🔙 **Returning to Main Menu...**", reply_markup=markup, parse_mode='Markdown')

        elif text == "📊 Global Stats" and user_id == ADMIN_ID:
            stats = db.get_stats() 
            stats_msg = (
                "📊 **GLOBAL LIFETIME STATS**\n"
                "━━━━━━━━━━━━━━━━━━\n"
                "⏳ **Total Pending:** `{}`\n\n"
                "✅ **Overall Valid:** `{}`\n"
                "❌ **Overall Invalid:** `{}`\n"
                "🧾 **Grand Total:** `{}`\n"
                "━━━━━━━━━━━━━━━━━━\n"
                "🌐 *System-wide activity log.*"
            ).format(stats.get('PENDING', 0), stats.get('VALID', 0), stats.get('INVALID', 0), stats.get('TOTAL', 0))
            bot.send_message(user_id, stats_msg, parse_mode='Markdown')

        elif text == "📜 System Logs" and user_id == ADMIN_ID:
            if os.path.exists("voucher_debug.log"):
                with open("voucher_debug.log", "rb") as f: bot.send_document(user_id, f)
            else:
                bot.send_message(user_id, "❌ **Log file not found.**", parse_mode='Markdown')

    # --- ADMIN INPUT PROCESSORS ---
    def process_base_limit_update(message):
        if not message.text.isdigit():
            bot.send_message(ADMIN_ID, "❌ **Invalid input.** Please send a number only.", parse_mode='Markdown')
            return
        new_limit = int(message.text)
        rdb.update_config(base_limit=new_limit)
        bot.send_message(ADMIN_ID, f"✅ **Success!** Base Daily Limit is now set to `{new_limit}`.", parse_mode='Markdown')

    def process_bonus_update(message):
        if not message.text.isdigit():
            bot.send_message(ADMIN_ID, "❌ **Invalid input.** Please send a number only.", parse_mode='Markdown')
            return
        new_bonus = int(message.text)
        rdb.update_config(bonus=new_bonus)
        bot.send_message(ADMIN_ID, f"✅ **Success!** Referral Bonus is now set to `+{new_bonus}` vouchers.", parse_mode='Markdown')

    # --- CALLBACK HANDLER ---
    @bot.callback_query_handler(func=lambda call: True)
    def handle_inline_buttons(call):
        user_id = call.from_user.id
        
        if call.data == "verify_join":
            if is_user_joined(user_id):
                referrer = rdb.confirm_referral(user_id)
                if referrer:
                    # --- STRICT ADAPT: Notification modified for Unlimited goal ---
                    try: bot.send_message(referrer, "🎉 **New Referral!** Your friend joined. Check `/refer` to see your progress towards UNLIMITED vouchers!", parse_mode='Markdown')
                    except: pass
                bot.answer_callback_query(call.id, "✅ Membership Verified! Welcome.")
                bot.delete_message(call.message.chat.id, call.message.message_id)
                bot.send_message(user_id, "✅ Use /start to open your dashboard again.")
            else:
                bot.answer_callback_query(call.id, "❌ You haven't joined all groups yet!", show_alert=True)

        elif call.data == "ref_leaderboard":
            lb = rdb.get_leaderboard()
            if not lb:
                bot.answer_callback_query(call.id, "❌ No referrals found yet.", show_alert=True)
                return
            text = "🏆 **REFERRAL LEADERBOARD**\n━━━━━━━━━━━━━━━━━━\n"
            for i, (uid, count) in enumerate(lb, 1):
                text += f"{i}. ID: `{uid}` ➜ **{count} Invites**\n"
            text += "━━━━━━━━━━━━━━━━━━"
            bot.send_message(user_id, text, parse_mode='Markdown')
            bot.answer_callback_query(call.id)

        elif call.data == "edit_base":
            m = bot.send_message(user_id, "⌨️ **Enter New Base Daily Limit:**\n(Current users will be updated automatically)", parse_mode='Markdown')
            bot.register_next_step_handler(m, process_base_limit_update)
            bot.answer_callback_query(call.id)

        elif call.data == "edit_bonus":
            m = bot.send_message(user_id, "⌨️ **Enter New Bonus Per Invite:**\n(Amount to add for each referral)", parse_mode='Markdown')
            bot.register_next_step_handler(m, process_bonus_update)
            bot.answer_callback_query(call.id)

        elif call.data == "refresh_live":
            dashboard = live_activity.get_live_dashboard()
            bot.edit_message_text(dashboard, call.message.chat.id, call.message.message_id, reply_markup=kb.get_live_dashboard_inline(), parse_mode='Markdown')
            bot.answer_callback_query(call.id, "Dashboard Refreshed!")
        
        elif call.data == "close_live":
            bot.delete_message(call.message.chat.id, call.message.message_id)
            bot.answer_callback_query(call.id, "Dashboard Closed.")

    # --- PROCESSING FUNCTIONS ---
    def process_add_vouchers(message):
        if message.text in ["➕ Add Vouchers", "📊 My Stats", "👥 Refer & Earn", "⚙️ Admin Panel", "📊 Global Stats", "📜 System Logs", "🔙 Back to Menu", "📡 Live Activity", "🛠️ Cookie Manager", "👥 Referral Manager"]:
            handle_text_buttons(message)
            return

        user_id = message.chat.id
        stats = rdb.get_user_limits(user_id)

        # --- STRICT ADAPT: Warning message updated to encourage Unlimited ---
        if stats['remaining'] <= 0 and not stats.get('is_unlimited', False):
            limit_msg = (
                "🚫 **Daily Limit Reached!**\n"
                f"Current Daily Limit: `{stats['limit']}`\n"
                "━━━━━━━━━━━━━━━━━━\n"
                "🚀 **WANT UNLIMITED?**\n"
                "Invite friends using the `👥 Refer & Earn` button to unlock unlimited checks instantly!"
            )
            bot.send_message(user_id, limit_msg, parse_mode='Markdown')
            return

        raw_text = message.text.upper()
        codes = re.findall(r'[A-Z0-9]{10,20}', raw_text)
        
        if not codes:
            bot.send_message(user_id, "❌ **No valid codes found.**", parse_mode='Markdown')
            return
        
        valid_to_add = codes[:stats['remaining']]
        ignored_count = len(codes) - len(valid_to_add)

        added = db.add_vouchers_to_queue(valid_to_add, user_id)
        rdb.update_usage(user_id, added) 
        
        initial_ui = f"✅ **{added} Vouchers Added!**\n"
        if ignored_count > 0:
            initial_ui += f"⚠️ **Notice:** `{ignored_count}` vouchers ignored (Daily limit reached).\n"
        
        initial_ui += (
            "──────────────────────\n"
            "● **STATUS** ➜ ⚙️ `Initializing Engine...`\n"
            "──────────────────────"
        )
        sent_msg = bot.send_message(message.chat.id, initial_ui, parse_mode='Markdown')
        
        if ignored_count > 0:
            time.sleep(3.5)
            
        db.update_user_batch_info(message.chat.id, sent_msg.message_id)
        