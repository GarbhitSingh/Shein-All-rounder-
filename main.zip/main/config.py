# config.py
BOT_TOKEN = "8770400668:AAGSxdMOlACPpuvC-HFOcBzlAKSeGuMPNNg"
ADMIN_ID = 421311524 
COOKIES_DIR = "cookies" 
CHECK_INTERVAL_SECONDS = 600 # 8 Minutes

VOUCHER_DETAILS = {
    "SVH": {"val": 4000, "desc": "High Tier"},
    "SV3": {"val": 5000, "desc": "Elite Tier"},
    "SVC": {"val": 1000, "desc": "Standard"},
    "SVD": {"val": 2000, "desc": "Mid Tier"},
    "SVI": {"val": 500,  "desc": "Basic"},
    "SVB": {"val": 500,  "desc": "Basic"}
}
