# referral_db.py
import sqlite3
from datetime import datetime

REF_DB = "referrals.db"

def get_ref_connection():
    return sqlite3.connect(REF_DB, check_same_thread=False)

def init_ref_db():
    conn = get_ref_connection()
    c = conn.cursor()
    
    # 1. Global Settings (Admin Control)
    c.execute('''CREATE TABLE IF NOT EXISTS global_config 
                 (id INTEGER PRIMARY KEY, base_limit INTEGER, bonus_per_refer INTEGER)''')
    
    # Insert default if empty (Base 50, Bonus 20) # You can change 50 to 25 if needed
    c.execute("SELECT COUNT(*) FROM global_config")
    if c.fetchone()[0] == 0:
        c.execute("INSERT INTO global_config (id, base_limit, bonus_per_refer) VALUES (1, 50, 20)")

    # 2. Tracking (Who invited whom)
    c.execute('''CREATE TABLE IF NOT EXISTS tracking 
                 (invited_id INTEGER PRIMARY KEY, referrer_id INTEGER, status TEXT)''')
    
    # 3. User Stats (Limits & Usage)
    c.execute('''CREATE TABLE IF NOT EXISTS user_stats 
                 (user_id INTEGER PRIMARY KEY, total_refers INTEGER DEFAULT 0, 
                  used_today INTEGER DEFAULT 0, last_reset TEXT, manual_limit INTEGER DEFAULT 0)''')
    
    # SAFEGUARD: Purane database mein naya column add karne ke liye
    try:
        c.execute("ALTER TABLE user_stats ADD COLUMN manual_limit INTEGER DEFAULT 0")
    except sqlite3.OperationalError:
        pass # Column pehle se hai, koi dikkat nahi
    
    conn.commit()
    conn.close()

# --- GLOBAL CONFIG MANAGEMENT ---
def get_config():
    conn = get_ref_connection()
    c = conn.cursor()
    c.execute("SELECT base_limit, bonus_per_refer FROM global_config WHERE id = 1")
    res = c.fetchone()
    conn.close()
    return {'base': res[0], 'bonus': res[1]}

def update_config(base_limit=None, bonus=None):
    conn = get_ref_connection()
    c = conn.cursor()
    if base_limit is not None:
        c.execute("UPDATE global_config SET base_limit = ? WHERE id = 1", (base_limit,))
    if bonus is not None:
        c.execute("UPDATE global_config SET bonus_per_refer = ? WHERE id = 1", (bonus,))
    conn.commit()
    conn.close()

# --- USER LOGIC & LIMITS ---
def check_reset(user_id):
    conn = get_ref_connection()
    c = conn.cursor()
    today = datetime.now().strftime('%Y-%m-%d')
    
    c.execute("SELECT last_reset FROM user_stats WHERE user_id = ?", (user_id,))
    res = c.fetchone()
    
    if not res:
        c.execute("INSERT INTO user_stats (user_id, last_reset) VALUES (?, ?)", (user_id, today))
    elif res[0] != today:
        c.execute("UPDATE user_stats SET used_today = 0, last_reset = ? WHERE user_id = ?", (today, user_id))
    
    conn.commit()
    conn.close()

def get_user_limits(user_id):
    check_reset(user_id)
    config = get_config()
    conn = get_ref_connection()
    c = conn.cursor()
    c.execute("SELECT total_refers, used_today, manual_limit FROM user_stats WHERE user_id = ?", (user_id,))
    res = c.fetchone()
    conn.close()
    
    refers = res[0] if res else 0
    used = res[1] if res else 0
    m_limit = res[2] if res else 0
    
    # --- STRICT ADAPT: New 2-Referral Unlimited Logic ---
    is_unlimited = False
    
    if m_limit > 0:
        limit = m_limit
        if limit >= 999999: is_unlimited = True
    elif refers >= 2:
        # 🚀 UNLIMITED MODE UNLOCKED
        limit = 999999
        is_unlimited = True
    else:
        # 🆓 FREE TIER (Base limit, ignores old bonus math to enforce the 2-referral rule strictly)
        limit = config['base']
        
    return {'limit': limit, 'used': used, 'remaining': max(0, limit - used), 'refers': refers, 'is_unlimited': is_unlimited}

def update_usage(user_id, count):
    conn = get_ref_connection()
    c = conn.cursor()
    c.execute("UPDATE user_stats SET used_today = used_today + ? WHERE user_id = ?", (count, user_id))
    conn.commit()
    conn.close()

# --- HIDDEN ADMIN LOGIC (Manual VIP Limits) ---
def set_manual_limit(user_id, amount):
    check_reset(user_id) # Isse confirm hoga ki user database me hai
    conn = get_ref_connection()
    c = conn.cursor()
    c.execute("UPDATE user_stats SET manual_limit = ? WHERE user_id = ?", (amount, user_id))
    conn.commit()
    conn.close()

# --- REFERRAL TRACKING ---
def log_referral_intent(invited_id, referrer_id):
    if str(invited_id) == str(referrer_id): return
    conn = get_ref_connection()
    c = conn.cursor()
    c.execute("INSERT OR IGNORE INTO tracking (invited_id, referrer_id, status) VALUES (?, ?, 'PENDING')", 
              (invited_id, referrer_id))
    conn.commit()
    conn.close()

def confirm_referral(user_id):
    conn = get_ref_connection()
    c = conn.cursor()
    c.execute("SELECT referrer_id FROM tracking WHERE invited_id = ? AND status = 'PENDING'", (user_id,))
    res = c.fetchone()
    if res:
        referrer_id = res[0]
        c.execute("UPDATE tracking SET status = 'JOINED' WHERE invited_id = ?", (user_id,))
        c.execute("UPDATE user_stats SET total_refers = total_refers + 1 WHERE user_id = ?", (referrer_id,))
        conn.commit()
        conn.close()
        return referrer_id
    conn.close()
    return None

def get_leaderboard():
    conn = get_ref_connection()
    c = conn.cursor()
    c.execute("SELECT user_id, total_refers FROM user_stats WHERE total_refers > 0 ORDER BY total_refers DESC LIMIT 10")
    res = c.fetchall()
    conn.close()
    return res
    