# keyboards.py
from telebot.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton

def main_menu_keyboard():
    # Main Dashboard Menu
    markup = ReplyKeyboardMarkup(row_width=2, resize_keyboard=True)
    btn_start = KeyboardButton("🛡️ Start Protection")
    btn_stop = KeyboardButton("🛑 Stop Protection")
    btn_list = KeyboardButton("📝 List Vouchers")
    btn_reserved = KeyboardButton("🚀 Reserved")
    btn_add = KeyboardButton("➕ Add Voucher")
    btn_activity = KeyboardButton("📊 Live Activity")
    btn_dead = KeyboardButton("💀 Dead History") 
    btn_clear = KeyboardButton("🗑️ Clear DB")
    
    markup.add(btn_start, btn_stop)
    markup.add(btn_list, btn_reserved)
    markup.add(btn_add, btn_activity)
    markup.add(btn_dead, btn_clear)
    return markup

def back_menu_keyboard():
    # Input state ke liye Back button
    markup = ReplyKeyboardMarkup(resize_keyboard=True)
    btn_back = KeyboardButton("🔙 Back to Menu")
    markup.add(btn_back)
    return markup

def reserved_menu_keyboard():
    # 🚀 Clean Submenu for Reserved Section
    markup = ReplyKeyboardMarkup(row_width=2, resize_keyboard=True)
    btn_add_res = KeyboardButton("🔒 Reserve a Code")
    btn_rel_res = KeyboardButton("🔓 Release a Code")
    btn_view_res = KeyboardButton("📋 View Reserved")
    btn_back = KeyboardButton("🔙 Back to Menu")
    
    markup.add(btn_add_res, btn_rel_res)
    markup.add(btn_view_res, btn_back)
    return markup

def confirm_clear_keyboard():
    # ⚠️ 2-Step Confirmation
    markup = ReplyKeyboardMarkup(resize_keyboard=True)
    btn_yes = KeyboardButton("⚠️ YES, CLEAR EVERYTHING")
    btn_back = KeyboardButton("🔙 Back to Menu")
    markup.add(btn_yes, btn_back)
    return markup

def activity_inline_buttons():
    # --- STRICT ADAPT: Force Scan Button Added Here ---
    markup = InlineKeyboardMarkup()
    btn_refresh = InlineKeyboardButton("🔄 Refresh", callback_data="refresh_activity")
    btn_force = InlineKeyboardButton("⚡ Force Scan", callback_data="force_scan") 
    btn_close = InlineKeyboardButton("❌ Close", callback_data="close_activity")
    
    markup.add(btn_refresh, btn_force) # Refresh aur Force Scan ek line me
    markup.add(btn_close) # Close button niche ki line me
    return markup

def dead_history_inline():
    # Dead history
    markup = InlineKeyboardMarkup()
    btn_clear_dead = InlineKeyboardButton("🗑️ Clear Dead History", callback_data="clear_dead_history")
    btn_close = InlineKeyboardButton("❌ Close", callback_data="close_activity")
    markup.add(btn_clear_dead, btn_close)
    return markup

# --- CLEAN BULK COPY KEYBOARDS ---

def voucher_list_inline():
    # Sirf Active list copy karne ke liye (No clutter)
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("📋 Copy All Active", callback_data="bulk_copy_all"))
    return markup

def reserved_list_inline():
    # Sirf Reserved list copy karne ke liye (No clutter)
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("📋 Copy All Reserved", callback_data="bulk_copy_reserved"))
    return markup
    