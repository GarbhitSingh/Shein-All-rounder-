import json, requests, os, glob, time
from config import COOKIES_DIR

VALID_DIR = COOKIES_DIR
EXPIRED_DIR = os.path.join(COOKIES_DIR, "expired_pool")

if not os.path.exists(EXPIRED_DIR):
    os.makedirs(EXPIRED_DIR)

def validate_cookie_accuracy(file_path):
    """100% Accurate validation for SHEIN cookies with Exact Headers."""
    try:
        # 1. Physical Validation
        if os.path.getsize(file_path) == 0:
            return "CORRUPT", "File is empty"

        with open(file_path, "r", encoding="utf-8") as f:
            content = f.read().strip()
            if not content: return "CORRUPT", "Blank content"
            data = json.loads(content)

        # 2. String Parsing & Clean-up (Strict Adapt)
        if isinstance(data, list):
            cookie_str = "; ".join(f"{c['name']}={c['value']}" for c in data if 'name' in c and 'value' in c)
        else:
            cookie_str = "; ".join(f"{k}={v}" for k, v in data.items())
            
        cookie_str = cookie_str.replace('\n', '').replace('\r', '').strip()

        # 3. EXACT HEADERS (From User Script)
        headers = {
            "accept": "application/json",
            "content-type": "application/json",
            "origin": "https://www.sheinindia.in",
            "referer": "https://www.sheinindia.in/cart",
            "user-agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36",
            "x-tenant-id": "SHEIN",
            "cookie": cookie_str
        }

        # 4. Precision Check: Applying a dummy voucher to see real session state
        url = "https://www.sheinindia.in/api/cart/apply-voucher"
        payload = {"voucherId": "PROBE_CHECK_123", "device": {"client_type": "web"}}
        
        response = requests.post(url, json=payload, headers=headers, timeout=15)
        
        # 5. Body Analysis (The secret to 100% accuracy)
        if response.status_code == 200:
            res_json = response.json()
            # Agar session dead hai, toh SHEIN aksar 'errorMessage' me login mangta hai
            err = str(res_json.get("errorMessage", "")).lower()
            if "login" in err or "sign in" in err or "unauthorized" in err:
                return "EXPIRED", "Session expired (Login required)"
            return "VALID", "Success"
        
        elif response.status_code in [401, 403]:
            return "EXPIRED", f"HTTP {response.status_code} - Unauthorized"
        
        return "UNKNOWN", f"Status {response.status_code}"

    except json.JSONDecodeError:
        return "CORRUPT", "Invalid JSON format"
    except Exception as e:
        return "ERROR", str(e)

def run_standalone_scanner():
    print("🚀 Starting 100% Accurate Cookie Scan...")
    files = glob.glob(os.path.join(COOKIES_DIR, "*.json"))
    
    if not files:
        print("⚠️ No .json files found in the cookie directory.")
        return
        
    report = {"VALID": 0, "EXPIRED": 0, "CORRUPT": 0, "ERROR": 0}

    for f in files:
        filename = os.path.basename(f)
        status, reason = validate_cookie_accuracy(f)
        
        if status == "VALID":
            report["VALID"] += 1
            print(f"✅ {filename}: WORKING")
        else:
            report[status if status in report else "ERROR"] += 1
            print(f"❌ {filename}: {status} ({reason})")
            # Move dead/corrupt files
            try:
                os.rename(f, os.path.join(EXPIRED_DIR, filename + f".{status.lower()}"))
            except Exception as e:
                print(f"   [!] Failed to move {filename}: {str(e)}")

    print("\n📊 --- FINAL SCAN REPORT ---")
    print(f"🟢 Valid: {report['VALID']} | 🔴 Expired/Corrupt: {report['EXPIRED'] + report['CORRUPT']}")
    print(f"📁 Dead files moved to: {EXPIRED_DIR}")

if __name__ == "__main__":
    run_standalone_scanner()
    