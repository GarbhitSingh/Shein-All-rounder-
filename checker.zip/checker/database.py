# database.py
import sqlite3
from config import DB_NAME
import time

def get_connection():
    return sqlite3.connect(DB_NAME, check_same_thread=False)

def init_db():
    conn = get_connection()
    c = conn.cursor()
    # Users Table
    c.execute('''CREATE TABLE IF NOT EXISTS users 
                 (user_id INTEGER PRIMARY KEY, role TEXT, last_msg_id INTEGER, batch_start_time REAL)''')
    
    # Smart Fallback for existing databases
    try:
        c.execute("ALTER TABLE users ADD COLUMN last_msg_id INTEGER")
        c.execute("ALTER TABLE users ADD COLUMN batch_start_time REAL")
    except sqlite3.OperationalError:
        pass 

    # Vouchers Queue Table
    c.execute('''CREATE TABLE IF NOT EXISTS queue 
                 (id INTEGER PRIMARY KEY AUTOINCREMENT, 
                  code TEXT, added_by INTEGER, status TEXT, added_at REAL)''')
    conn.commit()
    conn.close()

def add_user(user_id, role="USER"):
    conn = get_connection()
    try:
        conn.cursor().execute("INSERT OR IGNORE INTO users (user_id, role) VALUES (?, ?)", (user_id, role))
        conn.commit()
    finally:
        conn.close()

# --- Total Users Count Ke Liye ---
def get_total_users_count():
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM users")
    count = c.fetchone()[0]
    conn.close()
    return count

# --- STRICT ADAPT: Fixed Recent 5 Activity to show accurate stats ---
def get_recent_5_activity():
    conn = get_connection()
    c = conn.cursor()
    
    # FIXED: Group By User ID but ensure we don't duplicate count. 
    # This specifically checks all history for active users to match dashboard expectation accurately.
    c.execute("""
        SELECT added_by, 
               COUNT(*) as total,
               SUM(CASE WHEN status LIKE 'VALID%' THEN 1 ELSE 0 END) as valid,
               SUM(CASE WHEN status LIKE 'INVALID%' OR status = 'NOTIFIED' THEN 1 ELSE 0 END) as invalid
        FROM queue 
        GROUP BY added_by 
        ORDER BY MAX(added_at) DESC 
        LIMIT 5
    """)
    
    results = c.fetchall()
    conn.close()
    
    activity_list = []
    for row in results:
        activity_list.append({
            'uid': row[0],
            'total': row[1] or 0,
            'valid': row[2] or 0,
            'invalid': row[3] or 0
        })
    return activity_list

# --- STRICT ADAPT: User Inspection for Admin Troubleshoot ---
def inspect_user_vouchers(uid):
    """Fetches exact count of every status for a specific user ID."""
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT status, COUNT(*) FROM queue WHERE added_by = ? GROUP BY status", (uid,))
    results = c.fetchall()
    conn.close()
    return results

def is_authorized(user_id):
    return True

def add_vouchers_to_queue(codes, user_id):
    conn = get_connection()
    c = conn.cursor()
    added = 0
    for code in codes:
        c.execute("INSERT INTO queue (code, added_by, status, added_at) VALUES (?, ?, 'PENDING', ?)", 
                  (code.upper(), user_id, time.time()))
        added += 1
    conn.commit()
    conn.close()
    return added # STRICT ADAPT: Fixed the "None vouchers" bug

def get_pending_voucher():
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT id, code, added_by FROM queue WHERE status = 'PENDING' ORDER BY added_at ASC LIMIT 1")
    res = c.fetchone()
    conn.close()
    return res

def update_voucher_status(vid, status):
    conn = get_connection()
    c = conn.cursor()
    c.execute("UPDATE queue SET status = ? WHERE id = ?", (status, vid))
    conn.commit()
    conn.close()

def get_stats(user_id=None):
    """STRICT ADAPT: Lifetime Stats Calculation"""
    conn = get_connection()
    c = conn.cursor()
    if user_id:
        c.execute("SELECT status, COUNT(*) FROM queue WHERE added_by = ? GROUP BY status", (user_id,))
    else:
        c.execute("SELECT status, COUNT(*) FROM queue GROUP BY status")
    
    raw_stats = {row[0]: row[1] for row in c.fetchall()}
    conn.close()

    # Lifetime Logic: Summing Active + Reported statuses
    pending = raw_stats.get('PENDING', 0)
    # Total Valid = Current Valid + Reported Valid (Archive)
    valid = raw_stats.get('VALID', 0) + raw_stats.get('VALID_REPORTED', 0)
    # Total Invalid = Current Invalid + Reported Invalid (Archive)
    invalid = raw_stats.get('INVALID', 0) + raw_stats.get('INVALID_REPORTED', 0)
    # For backward compatibility with 'NOTIFIED' if any
    archived = raw_stats.get('NOTIFIED', 0)
    
    return {
        'PENDING': pending,
        'VALID': valid,
        'INVALID': invalid + archived,
        'TOTAL': valid + invalid + archived
    }

# --- FUNCTIONS FOR BATCH REPORTING (STRICT ADAPT) ---

def get_pending_count(user_id):
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM queue WHERE added_by = ? AND status = 'PENDING'", (user_id,))
    count = c.fetchone()[0]
    conn.close()
    return count

def get_valid_vouchers(user_id):
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT id, code FROM queue WHERE added_by = ? AND status = 'VALID'", (user_id,))
    res = c.fetchall()
    conn.close()
    return res

def get_invalid_vouchers(user_id):
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT id, code FROM queue WHERE added_by = ? AND status = 'INVALID'", (user_id,))
    res = c.fetchall()
    conn.close()
    return res

def mark_as_reported(user_id):
    """STRICT ADAPT: Archive to specific reported status instead of generic NOTIFIED"""
    conn = get_connection()
    c = conn.cursor()
    # VALID ko VALID_REPORTED aur INVALID ko INVALID_REPORTED mark karo taaki stats yaad rahein
    c.execute("UPDATE queue SET status = 'VALID_REPORTED' WHERE added_by = ? AND status = 'VALID'", (user_id,))
    c.execute("UPDATE queue SET status = 'INVALID_REPORTED' WHERE added_by = ? AND status = 'INVALID'", (user_id,))
    conn.commit()
    conn.close()

def is_already_reported(user_id):
    """STRICT ADAPT: Double-Gate Lock to prevent multiple reports."""
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM queue WHERE added_by = ? AND status IN ('VALID', 'INVALID')", (user_id,))
    count = c.fetchone()[0]
    conn.close()
    return count == 0

# --- UI & TIMING FUNCTIONS (STRICT ADAPT) ---

def get_batch_progress(user_id):
    """STRICT ADAPT: Keep Live UI focused only on the ACTIVE batch"""
    conn = get_connection()
    c = conn.cursor()
    # Archive statuses ko UI progress se bahar rakha hai
    c.execute("""SELECT status, COUNT(*) FROM queue 
                 WHERE added_by = ? 
                 AND status NOT IN ('VALID_REPORTED', 'INVALID_REPORTED', 'NOTIFIED') 
                 GROUP BY status""", (user_id,))
    results = dict(c.fetchall())
    conn.close()

    pending = results.get('PENDING', 0)
    valid = results.get('VALID', 0)
    invalid = results.get('INVALID', 0)
    checked = valid + invalid

    return {
        'pending': pending, 
        'valid': valid, 
        'invalid': invalid, 
        'checked': checked, 
        'total': pending + checked
    }

def get_batch_start_time(user_id):
    conn = get_connection()
    c = conn.cursor()
    c.execute('SELECT batch_start_time FROM users WHERE user_id = ?', (user_id,))
    result = c.fetchone()
    conn.close()
    return result[0] if result and result[0] else time.time()

def get_status_msg_id(user_id):
    conn = get_connection()
    c = conn.cursor()
    c.execute('SELECT last_msg_id FROM users WHERE user_id = ?', (user_id,))
    result = c.fetchone()
    conn.close()
    return result[0] if result else None

def update_user_batch_info(user_id, msg_id):
    conn = get_connection()
    c = conn.cursor()
    c.execute('''UPDATE users SET last_msg_id = ?, batch_start_time = ? 
                 WHERE user_id = ?''', (msg_id, time.time(), user_id))
    conn.commit()
    conn.close()
    