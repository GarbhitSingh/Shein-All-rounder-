# checker.py
import json, requests, time, random, os, logging, glob, threading
from config import COOKIES_DIR, VOUCHER_DETAILS
import database as db
import live_activity 

logging.basicConfig(filename='voucher_debug.log', level=logging.DEBUG,
                    format='%(asctime)s - %(levelname)s - [%(funcName)s] - %(message)s')

last_ui_update = 0 
report_lock = threading.Lock() 

def load_random_cookie():
    files = glob.glob(os.path.join(COOKIES_DIR, "*.json"))
    if not files: return None
    chosen_file = random.choice(files)
    try:
        with open(chosen_file, "r", encoding="utf-8") as f:
            raw = f.read().strip()
            cookie_data = json.loads(raw)
            if isinstance(cookie_data, list):
                c_str = "; ".join(f"{c['name']}={c['value']}" for c in cookie_data if 'name' in c and 'value' in c)
            else:
                c_str = "; ".join(f"{k}={v}" for k, v in cookie_data.items())
            return c_str.replace('\n', '').replace('\r', '').strip()
    except: 
        return None

# --- EXACT HEADERS FROM USER SCRIPT ---
def get_headers(cookie_string):
    return {
        "accept": "application/json", "content-type": "application/json",
        "origin": "https://www.sheinindia.in", "referer": "https://www.sheinindia.in/cart",
        "user-agent": "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 Chrome/142.0.0.0 Safari/537.36",
        "x-tenant-id": "SHEIN", "cookie": cookie_string
    }

def check_voucher_session(session, voucher_code, headers):
    url = "https://www.sheinindia.in/api/cart/apply-voucher"
    payload = {"voucherId": voucher_code, "device": {"client_type": "web"}}
    try:
        res = session.post(url, json=payload, headers=headers, timeout=45)
        try: 
            return res.status_code, res.json()
        except: 
            return res.status_code, {"errorMessage": "Server returned non-JSON"}
    except Exception as e:
        logging.error(f"Error {voucher_code}: {str(e)}")
        return None, None

def reset_voucher_session(session, voucher_code, headers):
    url = "https://www.sheinindia.in/api/cart/reset-voucher"
    try: 
        session.post(url, json={"voucherId": voucher_code, "device": {"client_type": "web"}}, headers=headers, timeout=20)
    except: 
        pass

def is_voucher_applicable(response_data):
    if not response_data: return False
    if "errorMessage" in response_data:
        if isinstance(response_data["errorMessage"], str) and "Block" in response_data["errorMessage"]: 
            return False
        errors = response_data.get("errorMessage", {}).get("errors", [])
        for error in errors:
            if error.get("type") == "VoucherOperationError":
                if "not applicable" in error.get("message", "").lower(): 
                    return False
    return "errorMessage" not in response_data

# --- STRICT ADAPT: 100% ACCURATE COOKIE MANAGER ---
def run_cookie_manager(bot, user_id):
    """STRICT ADAPT: Uses real voucher probe logic to ensure 100% accuracy."""
    files = glob.glob(os.path.join(COOKIES_DIR, "*.json"))
    results = {'total': len(files), 'valid': 0, 'expired': 0}
    
    if not files:
        bot.send_message(user_id, "⚠️ **No cookies found in pool.**", parse_mode='Markdown')
        return

    msg = bot.send_message(user_id, "🔍 **Precision-Scan Active...**\nVerifying sessions with SHEIN API probes.", parse_mode='Markdown')
    session = requests.Session()

    for file_path in files:
        try:
            # 1. Physical Check: If file is empty, mark as expired
            if os.path.getsize(file_path) == 0:
                raise ValueError("Ghost File (0 bytes)")

            with open(file_path, "r", encoding="utf-8") as f:
                raw = f.read().strip()
                if not raw: raise ValueError("Ghost File (Empty)")
                cookie_data = json.loads(raw)
            
            # String parsing
            if isinstance(cookie_data, list):
                cookie_str = "; ".join(f"{c['name']}={c['value']}" for c in cookie_data if 'name' in c and 'value' in c)
            else:
                cookie_str = "; ".join(f"{k}={v}" for k, v in cookie_data.items())
            cookie_str = cookie_str.replace('\n', '').replace('\r', '').strip()

            headers = get_headers(cookie_str)
            
            # 2. Accuracy Check: Voucher Probe
            status, data = check_voucher_session(session, "PROBE_CHECK_123", headers)
            
            is_valid = False
            if status == 200 and data:
                err_msg = str(data.get("errorMessage", "")).lower()
                # Agar login nahi mang raha, matlab cookie zinda hai
                if "login" not in err_msg and "sign in" not in err_msg and "unauthorized" not in err_msg:
                    is_valid = True
            
            if is_valid:
                results['valid'] += 1
            else:
                results['expired'] += 1
                os.rename(file_path, file_path + ".expired")
                
        except (json.JSONDecodeError, ValueError):
            # Bad data or empty files
            results['expired'] += 1
            os.rename(file_path, file_path + ".expired")
        except Exception as e:
            # Network error par file delete nahi karenge (Safety first)
            logging.error(f"Manager Error on {file_path}: {str(e)}")
            results['valid'] += 1 
        
        time.sleep(1.2) # To avoid rate limiting

    final_ui = live_activity.get_cookie_validation_ui(results)
    bot.edit_message_text(final_ui, user_id, msg.message_id, parse_mode='Markdown')

# --- WORKER THREAD LOGIC (v3.4 Sync - Elite Categorized) ---
def worker_thread(bot, worker_id):
    global last_ui_update
    logging.info(f"Worker-{worker_id} Started.")
    session = requests.Session()
    
    while True:
        try: 
            live_activity.update_worker_state(worker_id, 'SLEEPING')
            voucher = db.get_pending_voucher()
            
            if not voucher:
                time.sleep(2) 
                continue
                
            live_activity.update_worker_state(worker_id, 'ACTIVE')
            vid, code, user_id = voucher
            cookie_string = load_random_cookie()
            
            if not cookie_string:
                time.sleep(10)
                continue
                
            headers = get_headers(cookie_string)
            status_code, data = check_voucher_session(session, code, headers)
            
            if status_code is None:
                time.sleep(2)
                continue 
                
            if is_voucher_applicable(data):
                db.update_voucher_status(vid, "VALID")
            else:
                db.update_voucher_status(vid, "INVALID")
                
            reset_voucher_session(session, code, headers)

            # --- SMART REFRESH LOGIC (3s Rate + Instant Finish) ---
            now = time.time()
            pending_count = db.get_pending_count(user_id)
            
            if (now - last_ui_update >= 3) or (pending_count == 0):
                last_ui_update = now
                progress = db.get_batch_progress(user_id) 
                
                live_ui = live_activity.get_user_batch_ui(progress)

                try:
                    msg_id = db.get_status_msg_id(user_id)
                    bot.edit_message_text(live_ui, user_id, msg_id, parse_mode='Markdown')
                except Exception as ui_e:
                    if "message is not modified" not in str(ui_e):
                        logging.error(f"UI Update Error: {str(ui_e)}")
            
            # --- BATCH REPORTING LOGIC (v3.4 Elite - Optimized) ---
            if pending_count == 0:
                with report_lock: 
                    # Gate 1: Double check pending count
                    if db.get_pending_count(user_id) > 0:
                        continue
                    
                    # Gate 2: Check database if already reported
                    if hasattr(db, 'is_already_reported') and db.is_already_reported(user_id):
                        continue
                        
                    # FETCH DATA FIRST
                    valid_vouchers = db.get_valid_vouchers(user_id)
                    invalid_vouchers = db.get_invalid_vouchers(user_id) if hasattr(db, 'get_invalid_vouchers') else [] 
                    
                    v_count = len(valid_vouchers)
                    i_count = len(invalid_vouchers)
                    total_processed = v_count + i_count
                    
                    if total_processed == 0:
                        continue

                    # Timing Logic
                    start_time = db.get_batch_start_time(user_id)
                    duration = int(time.time() - start_time)
                    mins, secs = divmod(duration, 60)

                    # Grouping Logic for Elite Report
                    grouped = {}
                    total_value = 0
                    for v_id, v_code in valid_vouchers:
                        prefix = v_code[:3].upper()
                        details = VOUCHER_DETAILS.get(prefix, {'val': 0, 'desc': ''})
                        total_value += details['val']
                        if prefix not in grouped: 
                            grouped[prefix] = {
                                "codes": [], 
                                "desc": details['desc'], 
                                "rate": details['val']
                            }
                        grouped[prefix]["codes"].append({"code": v_code, "val": details['val']})

                    # --- 1. TELEGRAM UI REPORT (One-Tap Copy Fix) ---
                    report = "✅ **SHEIN BATCH REPORT COMPLETE**\n"
                    report += "──────────────────────\n"
                    report += f"💰 **Total Value Found:** `Rs. {total_value}`\n"
                    report += f"📊 **Stats:** `{v_count:02d}` Valid | `{i_count:02d}` Dead\n"
                    report += f"⏱ **Time:** `{mins:02d}m {secs:02d}s`\n"
                    report += "──────────────────────\n"
                    
                    if valid_vouchers:
                        for prefix, info in grouped.items():
                            header_title = f"{prefix} SERIES"
                            if info['desc']: header_title += f" ({info['desc']})"
                            
                            report += f"\n🔥 **{header_title}**\n"
                            for c in info["codes"]:
                                # Removed amount for clean copying, wrapped in backticks
                                report += f"├ `{c['code']}`\n"
                    else:
                        report += "\n❌ **Result:** No valid vouchers found.\n"
                        report += "──────────────────────\n"

                    report += "\n📄 **Detailed report attached below.**"
                    bot.send_message(user_id, report, parse_mode='Markdown')

                    # --- 2. THE CATEGORIZED .TXT LOG (Clean Fix) ---
                    filename = f"Voucher_Report_{user_id}_{int(time.time())}.txt"
                    with open(filename, "w", encoding="utf-8") as f:
                        f.write("====================================\n")
                        f.write("      SHEIN VALID VOUCHERS REPORT   \n")
                        f.write(f"      Date: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
                        f.write(f"      Time: {mins:02d}m {secs:02d}s\n")
                        f.write("====================================\n\n")
                        
                        f.write("--- [ ✅ VALID VOUCHERS ] ---\n")
                        if valid_vouchers:
                            for prefix, info in grouped.items():
                                # Header logic: SVI SERIES (Rs. 500) [Desc]
                                f_header = f"--- {prefix} SERIES (Rs. {info['rate']})"
                                if info['desc']: f_header += f" [{info['desc']}]"
                                f_header += " ---"
                                
                                f.write(f"\n{f_header}\n")
                                for c in info["codes"]:
                                    # Amount removed here for clean text selection
                                    f.write(f"{c['code']}\n")
                        else:
                            f.write("\nNo valid vouchers found.\n")
                        
                        f.write("\n" + "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n")
                        f.write(f"TOTAL VALUE: Rs. {total_value}\n")
                        f.write("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n")
                        
                        # Invalid section
                        f.write(f"--- [ ❌ DEAD / INVALID VOUCHERS ({i_count}) ] ---\n")
                        if invalid_vouchers:
                            for _, inv_code in invalid_vouchers:
                                f.write(f"{inv_code}\n")
                        else:
                            f.write("None found.\n")
                            
                        f.write("\n====================================\n")
                        f.write(f"     END OF SYSTEM REPORT      \n")
                        f.write("====================================\n")
                            
                    with open(filename, "rb") as doc: 
                        bot.send_document(user_id, doc)
                    if os.path.exists(filename): 
                        os.remove(filename) 
                    
                    # Mark as reported at the end
                    db.mark_as_reported(user_id)

        except Exception as main_e:
            logging.error(f"CRITICAL: Worker-{worker_id} crashed. Restarting... Error: {str(main_e)}")
            time.sleep(5)
            continue 
            