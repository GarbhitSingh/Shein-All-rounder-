# main.py
import telebot, threading, os, glob, sys
from telebot.types import BotCommand
from telebot.apihelper import ApiTelegramException # <--- ADDED FOR CONFLICT DETECTION
from config import BOT_TOKEN, ADMIN_ID, COOKIES_DIR
import database as db
import referral_db as rdb
import checker
import bot_handlers # <--- Saare naye handlers yahan se import ho rahe hain

# Initialize Databases and Admin
db.init_db()
db.add_user(ADMIN_ID, "ADMIN")
rdb.init_ref_db() 

# Initialize Bot
bot = telebot.TeleBot(BOT_TOKEN, threaded=True)

# --- MENU SETUP ---
def setup_bot_commands():
    commands = [
        BotCommand("start", "🚀 Open Dashboard & Menu"),
        BotCommand("refer", "👥 Get Invite Link"),
        BotCommand("stats", "📊 View Lifetime Stats")
    ]
    bot.set_my_commands(commands)
    print("✅ Bot side menu commands updated.")

if __name__ == "__main__":
    if not os.path.exists(COOKIES_DIR):
        os.makedirs(COOKIES_DIR)
        
    cookie_files = glob.glob(os.path.join(COOKIES_DIR, "*.json"))
    num_cookies = len(cookie_files)
    
    # 🚀 Magic Happens Here: Saare Handlers ko bot se attach kar rahe hain
    bot_handlers.register_all_handlers(bot)
    setup_bot_commands()
    
    num_threads = max(1, min(num_cookies, 10)) 
    print(f"🚀 Found {num_cookies} cookies. Starting {num_threads} Worker Threads...")
    
    for i in range(num_threads):
        t = threading.Thread(target=checker.worker_thread, args=(bot, i))
        t.daemon = True
        t.start()
        
    print("✅ Bot is online and polling!")
    
    # --- STRICT ADAPT: 409 CONFLICT AUTO-STOP LOGIC ---
    try:
        # Added timeouts to prevent hang states
        bot.infinity_polling(timeout=60, long_polling_timeout=20)
    except ApiTelegramException as e:
        if e.error_code == 409:
            print("\n⚠️ [CRITICAL] 409 Conflict Detected!")
            print("🛑 Another bot instance is already running. Auto-stopping this ghost instance to prevent database corruption.")
            sys.exit(1) # Instantly kills this script
        else:
            print(f"\n❌ Telegram API Error: {e}")
    except Exception as e:
        print(f"\n❌ Unexpected Polling Error: {e}")
        