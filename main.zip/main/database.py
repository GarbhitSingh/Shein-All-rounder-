# database.py
import sqlite3
import datetime

def init_db():
    conn = sqlite3.connect('vouchers.db')
    # Active vouchers table
    conn.execute('CREATE TABLE IF NOT EXISTS vouchers (code TEXT PRIMARY KEY)')
    
    # STRICT ADAPT: Safe migration taaki purana database crash na ho
    try:
        conn.execute("ALTER TABLE vouchers ADD COLUMN status TEXT DEFAULT 'active'")
        conn.execute("ALTER TABLE vouchers ADD COLUMN reserved_at TEXT")
    except sqlite3.OperationalError:
        pass # Columns pehle se exist karte hain toh ignore karo

    # Dead vouchers history table
    conn.execute('CREATE TABLE IF NOT EXISTS dead_vouchers (code TEXT PRIMARY KEY, time TEXT, reason TEXT)')
    conn.commit()
    conn.close()

def get_v_count():
    conn = sqlite3.connect('vouchers.db')
    count = conn.execute('SELECT COUNT(*) FROM vouchers').fetchone()[0]
    conn.close()
    return count

def add_batch_vouchers(codes):
    conn = sqlite3.connect('vouchers.db')
    for c in codes:
        # Naye vouchers by default 'active' rahenge
        conn.execute('INSERT OR IGNORE INTO vouchers (code, status) VALUES (?, ?)', (c.upper(), 'active'))
    conn.commit()
    conn.close()

def get_all_vouchers():
    """Sare vouchers (active + reserved) ki list return karega"""
    conn = sqlite3.connect('vouchers.db')
    codes = [row[0] for row in conn.execute('SELECT code FROM vouchers').fetchall()]
    conn.close()
    return codes

def delete_voucher(code):
    conn = sqlite3.connect('vouchers.db')
    conn.execute('DELETE FROM vouchers WHERE code = ?', (code,))
    conn.commit()
    conn.close()

# --- NEW: FAST-APPLY RESERVATION LOGIC ---

def get_active_vouchers():
    """Sirf wo vouchers fetch karega jo 'active' hain (Protection loop ke liye)"""
    conn = sqlite3.connect('vouchers.db')
    # status IS NULL un purane vouchers ko handle karega jo naye update se pehle DB me the
    codes = [row[0] for row in conn.execute("SELECT code FROM vouchers WHERE status = 'active' OR status IS NULL").fetchall()]
    conn.close()
    return codes

def get_reserved_vouchers():
    """Sirf wo vouchers fetch karega jo 10 min lock se bachane ke liye reserve kiye hain"""
    conn = sqlite3.connect('vouchers.db')
    codes = [row[0] for row in conn.execute("SELECT code FROM vouchers WHERE status = 'reserved'").fetchall()]
    conn.close()
    return codes

def set_voucher_status(code, status):
    """Voucher ka status 'active' ya 'reserved' set karta hai aur time note karta hai"""
    conn = sqlite3.connect('vouchers.db')
    reserved_time = datetime.datetime.now().isoformat() if status == 'reserved' else None
    conn.execute("UPDATE vouchers SET status = ?, reserved_at = ? WHERE code = ?", (status, reserved_time, code))
    conn.commit()
    conn.close()

def auto_release_reserved():
    """Jo vouchers 30 mins se zyada reserved hain, unhe wapas active kar deta hai"""
    conn = sqlite3.connect('vouchers.db')
    now = datetime.datetime.now()
    vouchers = conn.execute("SELECT code, reserved_at FROM vouchers WHERE status = 'reserved'").fetchall()
    released_count = 0
    
    for code, r_time in vouchers:
        if r_time:
            reserved_at = datetime.datetime.fromisoformat(r_time)
            # 30 minutes = 1800 seconds
            if (now - reserved_at).total_seconds() > 1800:
                conn.execute("UPDATE vouchers SET status = 'active', reserved_at = NULL WHERE code = ?", (code,))
                released_count += 1
                
    conn.commit()
    conn.close()
    return released_count

# --- DEAD HISTORY LOGIC ---

def move_to_dead(code, reason="Invalid/Expired"):
    """Voucher ko active se delete karke dead history mein daalta hai"""
    conn = sqlite3.connect('vouchers.db')
    timestamp = datetime.datetime.now().strftime("%d-%m %H:%M:%S")
    
    # 1. Dead table mein save karo
    conn.execute('INSERT OR IGNORE INTO dead_vouchers VALUES (?, ?, ?)', (code, timestamp, reason))
    # 2. Active table se uda do
    conn.execute('DELETE FROM vouchers WHERE code = ?', (code,))
    
    conn.commit()
    conn.close()

def get_dead_vouchers():
    """Pichle dead vouchers ki list nikalta hai (latest pehle)"""
    conn = sqlite3.connect('vouchers.db')
    # Limit 50 rakhi hai taaki message lamba na ho jaye
    records = conn.execute('SELECT code, time, reason FROM dead_vouchers ORDER BY time DESC LIMIT 50').fetchall()
    conn.close()
    return records

def clear_dead_history():
    """Dead history ko saaf karne ke liye"""
    conn = sqlite3.connect('vouchers.db')
    conn.execute('DELETE FROM dead_vouchers')
    conn.commit()
    conn.close()
    