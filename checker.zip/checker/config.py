# config.py

# --- Bot Credentials ---
BOT_TOKEN = "8235234020:AAE5pbSHd4eoZsAhcYyVH7EhKYAa2hbCHkk" 
ADMIN_ID = 421311524 

# --- Mandatory Join Settings ---
# Bot MUST be an Admin in these chats to verify membership
REQUIRED_CHATS = ["@ThisIsBotGroup", "@ghostops_officialgrp", "@thebotgroup1"]

# --- File & Database Paths ---
DB_NAME = "bot_database.db"
COOKIES_DIR = "cookies" 
VALID_FILE = "valid_vouchers.txt"

# --- Voucher Mapping (Value + Series Description) ---
VOUCHER_DETAILS = {
    "SVH": {"val": 4000, "desc": ""},
    "SVC": {"val": 1000, "desc": ""},
    "SVD": {"val": 2000, "desc": ""},
    "SVI": {"val": 500,  "desc": ""},
    "SVB": {"val": 500,  "desc": "Min. Cart Rs. 1,000"} 
}
