# keyboards.py
from telebot.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton

def get_join_keyboard():
    markup = InlineKeyboardMarkup()
    markup.row(InlineKeyboardButton("📢 Main Group", url="https://t.me/ThisIsBotGroup"))
    markup.row(InlineKeyboardButton("👥 GhostOps Group", url="https://t.me/ghostops_officialgrp"))
    markup.row(InlineKeyboardButton("🔄 Backup Channel", url="https://t.me/thebotgroup1"))
    markup.row(InlineKeyboardButton("✅ I Have Joined", callback_data="verify_join"))
    return markup

def get_user_keyboard():
    markup = ReplyKeyboardMarkup(resize_keyboard=True)
    markup.row(KeyboardButton("➕ Add Vouchers"))
    markup.row(KeyboardButton("📊 My Stats"), KeyboardButton("👥 Refer & Earn"))
    return markup

def get_admin_keyboard():
    markup = ReplyKeyboardMarkup(resize_keyboard=True)
    markup.row(KeyboardButton("➕ Add Vouchers"))
    markup.row(KeyboardButton("📊 My Stats"), KeyboardButton("👥 Refer & Earn"))
    markup.row(KeyboardButton("📡 Live Activity"), KeyboardButton("⚙️ Admin Panel"))
    return markup

def get_admin_panel_keyboard():
    markup = ReplyKeyboardMarkup(resize_keyboard=True)
    markup.row(KeyboardButton("📊 Global Stats"), KeyboardButton("👥 Referral Manager"))
    markup.row(KeyboardButton("🛠️ Cookie Manager"), KeyboardButton("📜 System Logs"))
    markup.row(KeyboardButton("🔙 Back to Menu"))
    return markup

def get_ref_manager_inline():
    markup = InlineKeyboardMarkup()
    markup.row(InlineKeyboardButton("🏆 Leaderboard", callback_data="ref_leaderboard"))
    markup.row(InlineKeyboardButton("⚙️ Edit Base Limit", callback_data="edit_base"), 
               InlineKeyboardButton("⚙️ Edit Bonus", callback_data="edit_bonus"))
    return markup

def get_live_dashboard_inline():
    markup = InlineKeyboardMarkup()
    markup.row(InlineKeyboardButton("🔄 Refresh", callback_data="refresh_live"),
               InlineKeyboardButton("❌ Close", callback_data="close_live"))
    return markup
