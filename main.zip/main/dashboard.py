# dashboard.py
import time, datetime
from database import get_v_count

# Global stats jo protection_loop se update honge
stats = {
    "status": "Offline 🔴",
    "last_scan": "N/A",
    "next_scan": "Waiting...",
    "dead_today": 0,
    "active_cookie": "None"
}

def get_dashboard_text():
    v_count = get_v_count()
    text = (
        "🎮 **SHEIN PROTECTOR DASHBOARD**\n"
        "───────────────────\n"
        f"🛡️ **Status:** `{stats['status']}`\n"
        f"📝 **Vouchers:** `{v_count} Total` | 💀 **Dead:** `{stats['dead_today']}`\n"
        f"🍪 **Cookie:** `{stats['active_cookie']}`\n"
        "───────────────────\n"
        f"🕒 **Last Scan:** `{stats['last_scan']}`\n"
        f"⏳ **Next Scan:** `{stats['next_scan']}`\n"
        "───────────────────\n"
        f"_Last UI Refresh: {time.strftime('%H:%M:%S')}_"
    )
    return text
    