# main.py
import telebot, threading, time, requests, datetime
from config import *
from shein_api import *
from keyboards import *
import database as db
import dashboard as dash

bot = telebot.TeleBot(BOT_TOKEN)
protection_active = False
user_states = {}

def immediate_check_on_add(chat_id, codes):
    """Naye codes add hote hi unhe ek baar turant check karne ke liye"""
    session = requests.Session()
    cookie_str, fname = get_random_cookie(COOKIES_DIR)
    
    if not fname:
        bot.send_message(chat_id, "❌ Error: No cookies found for immediate check.")
        return

    headers = get_headers(cookie_str)
    if validate_session(session, headers, fname):
        for code in codes:
            code = code.upper()
            data = check_voucher_session(session, code, headers)
            
            if is_voucher_applicable(data):
                bot.send_message(chat_id, f"✅ **VOUCHER IS LIVE:** `{code}`\n_(Protection loop monitoring started)_", parse_mode="Markdown")
            else:
                db.move_to_dead(code)
                dash.stats["dead_today"] += 1 
                bot.send_message(chat_id, f"🚨 **VOUCHER DIED INSTANTLY:** `{code}`\n_(Removed from DB)_", parse_mode="Markdown")
            
            reset_voucher_session(session, code, headers)
            time.sleep(1)

# --- STRICT ADAPT: 8 MINUTE AUTO-ALERT LOGIC ---
def notify_unlocked(chat_id, code):
    """Exactly 8 minutes (480 seconds) wait karke user ko notify karega"""
    time.sleep(480) 
    
    # Release check: Agar user ne 8 min se pehle hi khud release kar diya ho, toh alert mat bhejo
    res = db.get_reserved_vouchers()
    if code in res:
        text = (
            f"⚡ **8 MINUTE OVER: VOUCHER UNLOCKED!**\n"
            f"───────────────────\n"
            f"🎫 **Code:** `{code}`\n"
            f"🕒 **Timer:** Exactly 8:00 Passed\n\n"
            f"_Bhai, lock khatam! Bot ise touch nahi kar raha, jaldi apply karo._"
        )
        bot.send_message(chat_id, text, parse_mode="Markdown")
        # Direct tap-to-copy
        bot.send_message(chat_id, f"`{code}`", parse_mode="Markdown")

def update_dashboard_ui(chat_id, message_id):
    try:
        bot.edit_message_text(
            dash.get_dashboard_text(), 
            chat_id, 
            message_id, 
            parse_mode="Markdown", 
            reply_markup=activity_inline_buttons()
        )
    except Exception as e:
        if "message is not modified" not in str(e).lower():
            print(f"📊 UI Refresh Error: {e}")

def manual_scan_logic(chat_id, message_id):
    """Sare active vouchers ko ek baar turant scan karne ke liye aur dashboard timer reset karne ke liye"""
    active_vouchers = db.get_active_vouchers()
    if not active_vouchers:
        bot.send_message(chat_id, "📭 Force scan ke liye koi Active voucher nahi mila.")
        return

    bot.send_message(chat_id, f"⚡ **FORCE SCAN START:** {len(active_vouchers)} codes check ho rahe hain...")
    
    session = requests.Session()
    cookie_str, fname = get_random_cookie(COOKIES_DIR)
    headers = get_headers(cookie_str)
    
    if validate_session(session, headers, fname):
        for code in active_vouchers:
            data = check_voucher_session(session, code, headers)
            if not is_voucher_applicable(data):
                db.move_to_dead(code)
                dash.stats["dead_today"] += 1
                bot.send_message(chat_id, f"🚨 **DIED DURING FORCE SCAN:** `{code}`", parse_mode="Markdown")
            reset_voucher_session(session, code, headers)
            time.sleep(1.5)

    now = datetime.datetime.now()
    dash.stats["last_scan"] = now.strftime("%H:%M:%S")
    next_t = now + datetime.timedelta(seconds=CHECK_INTERVAL_SECONDS)
    dash.stats["next_scan"] = next_t.strftime("%H:%M:%S")
    
    update_dashboard_ui(chat_id, message_id)
    bot.send_message(chat_id, f"✅ **FORCE SCAN COMPLETE.**\nAgla scan automatically {dash.stats['next_scan']} par hoga.")

def protection_loop(chat_id, message_id):
    global protection_active
    dash.stats["status"] = "Active 🟢"
    session = requests.Session()
    
    while protection_active:
        released = db.auto_release_reserved()
        if released > 0:
            bot.send_message(chat_id, f"🔄 {released} reserved vouchers auto-released back to protection (30m limit reached).")

        dash.stats["last_scan"] = time.strftime("%H:%M:%S")
        cookie_str, fname = get_random_cookie(COOKIES_DIR)
        dash.stats["active_cookie"] = fname or "Error"
        
        update_dashboard_ui(chat_id, message_id)
        
        all_vouchers = db.get_all_vouchers()
        if not all_vouchers:
            protection_active = False
            dash.stats["status"] = "Offline 🔴"
            update_dashboard_ui(chat_id, message_id)
            bot.send_message(chat_id, "⚠️ DB khali hai. Protection stopped.", reply_markup=main_menu_keyboard())
            break

        active_vouchers = db.get_active_vouchers()
        
        headers = get_headers(cookie_str)
        if validate_session(session, headers, fname):
            for code in active_vouchers:
                if not protection_active: break
                data = check_voucher_session(session, code, headers)
                
                if not is_voucher_applicable(data):
                    db.move_to_dead(code)
                    dash.stats["dead_today"] += 1
                    bot.send_message(chat_id, f"🚨 **VOUCHER DIED:** `{code}`\n_(Moved to Dead History)_", parse_mode="Markdown")
                
                reset_voucher_session(session, code, headers)
                time.sleep(2)
        
        next_t = datetime.datetime.now() + datetime.timedelta(seconds=CHECK_INTERVAL_SECONDS)
        dash.stats["next_scan"] = next_t.strftime("%H:%M:%S")
        update_dashboard_ui(chat_id, message_id)
        
        for _ in range(CHECK_INTERVAL_SECONDS):
            if not protection_active: break
            time.sleep(1)

# --- START COMMAND ---
@bot.message_handler(commands=['start', 'dash'])
def welcome(msg):
    if msg.from_user.id != ADMIN_ID: return
    user_states[msg.from_user.id] = None 
    bot.send_message(msg.chat.id, "🛡️ **SHEIN Protector Pro v2.0**\nDashboard loaded. Use buttons below.", 
                     reply_markup=main_menu_keyboard())

# --- KEYBOARD HANDLERS ---
@bot.message_handler(func=lambda msg: True)
def handle_menu(msg):
    global protection_active
    uid = msg.from_user.id
    if uid != ADMIN_ID: return

    text = msg.text.strip()

    if text == "🔙 Back to Menu":
        user_states[uid] = None
        bot.send_message(msg.chat.id, "🏠 Main Menu", reply_markup=main_menu_keyboard())
        return

    if user_states.get(uid) == "adding":
        codes = text.replace(',', ' ').split()
        if codes:
            db.add_batch_vouchers(codes)
            bot.send_message(msg.chat.id, f"✅ Added {len(codes)} codes. 🔍 Checking status...", reply_markup=main_menu_keyboard())
            threading.Thread(target=immediate_check_on_add, args=(msg.chat.id, codes), daemon=True).start()
        user_states[uid] = None
        return

    elif user_states.get(uid) == "waiting_for_reserve_input":
        code = text.upper()
        all_v = db.get_all_vouchers()
        if code in all_v:
            db.set_voucher_status(code, 'reserved')
            bot.send_message(msg.chat.id, f"🔒 `{code}` reserved for 30 mins.\n⏰ **Main theek 8 minute me tujhe alert bhej dunga!**", 
                             parse_mode="Markdown", reply_markup=reserved_menu_keyboard())
            
            # --- STRICT ADAPT: Alert Thread Started Here ---
            threading.Thread(target=notify_unlocked, args=(msg.chat.id, code), daemon=True).start()
        else:
            bot.send_message(msg.chat.id, "❌ Code DB me nahi mila. Check spelling.", reply_markup=reserved_menu_keyboard())
        user_states[uid] = None
        return

    elif user_states.get(uid) == "waiting_for_release_input":
        code = text.upper()
        all_v = db.get_all_vouchers()
        if code in all_v:
            db.set_voucher_status(code, 'active')
            bot.send_message(msg.chat.id, f"🔓 `{code}` is now active again.", 
                             parse_mode="Markdown", reply_markup=reserved_menu_keyboard())
        else:
            bot.send_message(msg.chat.id, "❌ Code DB me nahi mila.", reply_markup=reserved_menu_keyboard())
        user_states[uid] = None
        return

    if text == "🛡️ Start Protection":
        if not protection_active:
            protection_active = True
            bot.send_message(msg.chat.id, "🟢 Protection ON", reply_markup=main_menu_keyboard())
            m = bot.send_message(msg.chat.id, dash.get_dashboard_text(), 
                                 parse_mode="Markdown", reply_markup=activity_inline_buttons())
            threading.Thread(target=protection_loop, args=(msg.chat.id, m.message_id), daemon=True).start()
        else:
            bot.send_message(msg.chat.id, "⚠️ Already running.", reply_markup=main_menu_keyboard())

    elif text == "🛑 Stop Protection":
        protection_active = False
        dash.stats["status"] = "Offline 🔴"
        dash.stats["next_scan"] = "Stopped"
        bot.send_message(msg.chat.id, "🛑 Protection Stopped.", reply_markup=main_menu_keyboard())

    elif text == "📊 Live Activity":
        bot.send_message(msg.chat.id, dash.get_dashboard_text(), 
                         parse_mode="Markdown", reply_markup=activity_inline_buttons())

    elif text == "➕ Add Voucher":
        user_states[uid] = "adding"
        bot.send_message(msg.chat.id, "📝 Send Codes (space separated):", reply_markup=back_menu_keyboard())

    elif text == "📝 List Vouchers":
        vouchers = db.get_active_vouchers()
        if not vouchers:
            bot.send_message(msg.chat.id, "📭 No ACTIVE vouchers found.", reply_markup=main_menu_keyboard())
        else:
            indiv = "\n".join([f"• `{v}`" for v in vouchers])
            msg_text = f"📝 *ACTIVE VOUCHER LIST*\n───────────────────\n{indiv}"
            bot.send_message(msg.chat.id, msg_text, parse_mode="Markdown", reply_markup=voucher_list_inline())

    elif text == "🚀 Reserved":
        bot.send_message(msg.chat.id, "🚀 **RESERVED MENU**\nSelect an action:", 
                         parse_mode="Markdown", reply_markup=reserved_menu_keyboard())

    elif text == "🔒 Reserve a Code":
        user_states[uid] = "waiting_for_reserve_input"
        bot.send_message(msg.chat.id, "📝 **CODE PASTE KARO:**\nWo code bhejo jise 30 min ke liye reserve karna hai.", 
                         parse_mode="Markdown", reply_markup=back_menu_keyboard())

    elif text == "🔓 Release a Code":
        user_states[uid] = "waiting_for_release_input"
        bot.send_message(msg.chat.id, "🔓 **CODE PASTE KARO:**\nWo code bhejo jise wapas protection mein dalna hai.", 
                         parse_mode="Markdown", reply_markup=back_menu_keyboard())

    elif text == "📋 View Reserved":
        res = db.get_reserved_vouchers()
        if not res:
            bot.send_message(msg.chat.id, "📭 Abhi koi bhi voucher reserved nahi hai.")
        else:
            indiv = "\n".join([f"• `{v}`" for v in res])
            msg_text = f"🚀 *FAST-APPLY RESERVED*\n_(Bot is ignoring these)_\n───────────────────\n{indiv}"
            bot.send_message(msg.chat.id, msg_text, parse_mode="Markdown", reply_markup=reserved_list_inline())

    elif text == "💀 Dead History":
        dead_logs = db.get_dead_vouchers()
        if not dead_logs:
            bot.send_message(msg.chat.id, "✅ No dead vouchers yet!", reply_markup=main_menu_keyboard())
        else:
            log_list = "\n".join([f"• `{row[0]}` (Died: {row[1]})" for row in dead_logs])
            msg_text = f"💀 *DEAD VOUCHERS LOG*\n───────────────────\n{log_list}"
            bot.send_message(msg.chat.id, msg_text, parse_mode="Markdown", reply_markup=dead_history_inline())

    elif text == "🗑️ Clear DB":
        user_states[uid] = "waiting_for_clear_confirm"
        bot.send_message(msg.chat.id, "⚠️ *WARNING!*\n\nKya aap sach mein saare vouchers delete karna chahte hain?", parse_mode="Markdown", reply_markup=confirm_clear_keyboard())

    elif text == "⚠️ YES, CLEAR EVERYTHING":
        if user_states.get(uid) == "waiting_for_clear_confirm":
            import sqlite3
            conn = sqlite3.connect('vouchers.db')
            conn.execute('DELETE FROM vouchers')
            conn.commit()
            conn.close()
            user_states[uid] = None
            bot.send_message(msg.chat.id, "🗑️ Database has been wiped clean.", reply_markup=main_menu_keyboard())

# --- CALLBACK HANDLERS ---
@bot.callback_query_handler(func=lambda call: True)
def handle_callbacks(call):
    if call.data == "refresh_activity":
        update_dashboard_ui(call.message.chat.id, call.message.message_id)
        bot.answer_callback_query(call.id, "🔄 Stats Refreshed")
        
    elif call.data == "force_scan":
        if not protection_active:
            bot.answer_callback_query(call.id, "❌ Pehle Protection ON karo!", show_alert=True)
        else:
            bot.answer_callback_query(call.id, "⚡ Force Scan Triggered!")
            threading.Thread(target=manual_scan_logic, args=(call.message.chat.id, call.message.message_id), daemon=True).start()
            
    elif call.data == "close_activity":
        bot.delete_message(call.message.chat.id, call.message.message_id)

    elif call.data == "bulk_copy_all":
        vouchers = db.get_active_vouchers()
        if vouchers:
            v_joined = "\n".join(vouchers)
            bot.send_message(call.message.chat.id, f"`{v_joined}`", parse_mode="Markdown")
            bot.answer_callback_query(call.id, "📋 Active texts sent! Tap to copy.")
        else:
            bot.answer_callback_query(call.id, "📭 DB is empty.", show_alert=True)
            
    elif call.data == "bulk_copy_reserved":
        vouchers = db.get_reserved_vouchers()
        if vouchers:
            v_joined = "\n".join(vouchers)
            bot.send_message(call.message.chat.id, f"`{v_joined}`", parse_mode="Markdown")
            bot.answer_callback_query(call.id, "📋 Reserved texts sent! Tap to copy.")
        else:
            bot.answer_callback_query(call.id, "📭 Reserved list empty.", show_alert=True)
            
    elif call.data == "clear_dead_history":
        db.clear_dead_history()
        dash.stats["dead_today"] = 0 
        bot.edit_message_text("🗑️ *Dead history cleared.*", call.message.chat.id, call.message.message_id, parse_mode="Markdown")
        bot.answer_callback_query(call.id, "🗑️ Cleared & Stats Reset!")

if __name__ == "__main__":
    db.init_db()
    print("🚀 STRICT ADAPT: Bot is LIVE with 8-Min Auto-Alert for Reserved Vouchers.")
    bot.infinity_polling()
    