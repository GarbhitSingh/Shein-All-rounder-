# live_activity.py
import time
import database as db
import glob
import os
from config import COOKIES_DIR

# Dictionary to track worker states (ACTIVE/SLEEPING)
worker_status = {}

def update_worker_state(worker_id, state):
    global worker_status
    worker_status[worker_id] = state

def get_live_dashboard(bot=None):
    # 1. Stats Calculation
    try:
        total_users = db.get_total_users_count()
    except Exception:
        total_users = 0 # Failsafe agar DB update hone me delay ho
        
    total_cookies = len(glob.glob(os.path.join(COOKIES_DIR, "*.json")))
    active_workers = sum(1 for status in worker_status.values() if status == 'ACTIVE')
    sleeping_workers = sum(1 for status in worker_status.values() if status == 'SLEEPING')
    
    # 2. Queue Metrics from DB
    stats = db.get_stats()
    pending = stats.get('PENDING', 0)
    processed = stats.get('VALID', 0) + stats.get('INVALID', 0) + stats.get('NOTIFIED', 0)
    total_vouchers = pending + processed
    
    # 3. Alignment Logic for Clean Layout
    act_str = f"{active_workers:02d}"
    idl_str = f"{sleeping_workers:02d}"
    cok_str = f"{total_cookies:02d}"

    # --- RECENT 5 ACTIVITY FETCH LOGIC ---
    try:
        recent_5 = db.get_recent_5_activity()
    except Exception:
        recent_5 = []

    recent_list_ui = ""
    if not recent_5:
        recent_list_ui = "  No recent activity found."
    else:
        icons = ["➊", "➋", "➌", "➍", "➎"]
        for i, user in enumerate(recent_5):
            icon = icons[i] if i < 5 else str(i+1)
            name = str(user['uid'])
            if bot:
                try:
                    u_info = bot.get_chat(user['uid'])
                    name = f"@{u_info.username}" if u_info.username else str(user['uid'])
                except:
                    pass
            
            # Strict Adapt: Boxed Stats Format
            recent_list_ui += f"{icon} `{name}` » `[{user['total']:02d}]` v:`{user['valid']:02d}` d:`{user['invalid']:02d}`\n"
    
    # 4. Global Dashboard UI (v4.0 Elite Boxed Stats)
    dashboard = (
        "🛰 **MONITORING DASHBOARD**\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "● **STATUS:** 🟢 `ACTIVE`\n"
        f"● **USERS:** `{total_users}` (Growing 🚀)\n\n"
        "**[ RECENT ACTIVITY ]**\n"
        f"{recent_list_ui.strip()}\n\n"
        "**[ HARDWARE ]**\n"
        f"Nodes: `{act_str}` | Cookies: `{cok_str}` Accs\n"
        f"Total Traffic: `{total_vouchers}` Checked\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        f"🕒 `{time.strftime('%I:%M:%S %p')}`"
    )
    
    return dashboard

# --- STRICT ADAPT: COOKIE VALIDATOR UI ---
def get_cookie_validation_ui(results):
    """Generates the v3.1 Ultra-Sleek UI for Cookie Scan Results."""
    tot_str = f"{results.get('total', 0):02d}"
    val_str = f"{results.get('valid', 0):02d}"
    exp_str = f"{results.get('expired', 0):02d}"
    
    dashboard = (
        "🛠 **COOKIE SCAN RESULTS**\n"
        "──────────────────────\n"
        "● **STATUS** ➜ ✅ `Pool Optimized`\n\n"
        "**📈 STATS**\n"
        f"┃ Total   ➜ `{tot_str}` Accounts\n"
        f"┃ Valid   ➜ `{val_str}` Working\n"
        f"┃ Expired ➜ `{exp_str}` Dead\n\n"
        "**⚙️ ACTION TAKEN**\n"
        "» Dead sessions moved to `.expired`\n"
        "» Pool is ready for high-speed.\n"
        "──────────────────────\n"
        f"🕒 `{time.strftime('%I:%M:%S %p')}`"
    )
    return dashboard

# --- STRICT ADAPT: USER BATCH UI (Voucher Checking Progress) ---
def get_user_batch_ui(progress):
    """Generates the v3.1 Ultra-Sleek UI with Valid/Invalid live counters."""
    pending = progress.get('pending', 0)
    valid = progress.get('valid', 0)
    invalid = progress.get('invalid', 0)
    
    # Backward compatibility: Agar database se valid/invalid nahi aaya toh total checked ko invalid me dal dega temp display ke liye
    if valid == 0 and invalid == 0 and progress.get('checked', 0) > 0:
        invalid = progress.get('checked', 0)
        
    total = pending + valid + invalid
    
    # Estimation (Safe assume: ~2s per voucher)
    est_sec = pending * 2 
    m, s = divmod(est_sec, 60)
    time_str = f"{m:02d}m {s:02d}s" if m > 0 else f"{s:02d}s"
    
    dashboard = (
        "🚀 **BATCH PROGRESS v3.1**\n"
        "──────────────────────\n"
        "● **STATUS** ➜ 🔍 `Processing...`\n\n"
        "**📊 YOUR QUEUE**\n"
        f"┃ Pending ➜ `{pending}`\n"
        f"┃ Valid   ➜ `{valid}`\n"
        f"┃ Invalid ➜ `{invalid}`\n"
        f"┃ Total   ➜ `{total}`\n\n"
        "**⏱ ESTIMATION**\n"
        f"» Time Lft : `~{time_str}`\n"
        "» Engine   : `Level Max`\n"
        "──────────────────────\n"
        f"🕒 `{time.strftime('%I:%M:%S %p')}`"
    )
    return dashboard
    